from pathlib import Path
Path('D:\\a\\_temp\\native-tests\\test_worker_bootstrap_does_not0\\wrong_package_imported').write_bytes(b'wrong package')
raise RuntimeError('wrong package')
